var MetricsGraphicsDirective = function() {
	return {
        restrict: 'E',
        templateUrl: 'templates/metrics-graphics.tpl.html',
        controller: MetricsGraphicsCtrl
    };
};

var MetricsGraphicsHistogramDirective = function() {
	return {
        restrict: 'E',
        templateUrl: 'templates/histogram/histogram.tpl.html',
        controller: MetricsGraphicsHistogramCtrl
    };
};

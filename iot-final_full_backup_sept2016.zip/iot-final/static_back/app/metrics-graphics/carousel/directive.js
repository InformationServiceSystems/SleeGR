var MetricsGraphicsCarouselDirective = function() {
	return {
        restrict: 'E',
				scope: {},
        templateUrl: 'static/app/metrics-graphics/carousel/carousel.tpl.html',
        controller: MetricsGraphicsCarouselCtrl
    };
};
